#include <cstdio>
using namespace ::std;

int main()
{
    int i = 320;
    
    while (i >= 160)
    {
        printf("%d\n", i);
        i -= 20;
    }
    
}