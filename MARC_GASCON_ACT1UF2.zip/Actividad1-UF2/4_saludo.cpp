#include <cstdio>

using namespace std;

void saludo() 
{
    printf("Hola\n");
}

int main() 
{
    saludo();
}