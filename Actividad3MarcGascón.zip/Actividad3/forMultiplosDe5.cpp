#include <cstdio>
using namespace ::std;

int main()
{
    for(int i = 0; i <= 100; i++)
    {
        if(i % 5 == 0)
        {
            printf("%d\n", i);
        }
        
    }
    
}