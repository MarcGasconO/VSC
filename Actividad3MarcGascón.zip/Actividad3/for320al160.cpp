#include <cstdio>
using namespace ::std;

int main()
{
    for(int i = 320; i >= 160; i -= 20)
    {
        printf("%d\n", i);
    }
}